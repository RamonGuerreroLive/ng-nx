﻿using cf.interfaces;
using cf.original;
using System.Text.Json;

namespace cf.client.two
{
    public class ClientTwoUsers: UserImplimentationOriginal
    {

    }
}
