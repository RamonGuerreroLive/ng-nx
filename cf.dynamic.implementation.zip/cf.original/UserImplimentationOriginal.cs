﻿using cf.interfaces;
using System.Text.Json;

namespace cf.original
{
    public class User: IUser
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class UserImplimentationOriginal: IApiImplementation<User>
    {
        //public async Task<List<User>> GetUsersAsync(Dictionary<string, string> parameters)
        //{
        //    using var client = new HttpClient();
        //    var response = await client.GetStringAsync("https://jsonplaceholder.typicode.com/users");

        //    return JsonSerializer.Deserialize<List<User>>(response);
        //}

        public async Task<List<User>> GetUsersAsync(Dictionary<string, string> parameters)
        {
            using var client = new HttpClient();
            var response = await client.GetStringAsync("https://jsonplaceholder.typicode.com/users");
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            return JsonSerializer.Deserialize<List<User>>(response, options);
        }

    }
}
