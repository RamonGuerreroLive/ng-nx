using Microsoft.AspNetCore.Mvc;
using System.Reflection;
using cf.interfaces;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options =>
{
    options.AddPolicy("AnyCors",
        policy =>
        {
            policy
            .AllowAnyHeader()
            .AllowAnyOrigin()
            .AllowAnyMethod();
        });
});


// Load implementations from a folder
var implementations = new Dictionary<string, object>();
var implementationFolder = Path.Combine(AppContext.BaseDirectory, "Implementations");

LoadImplementations(implementationFolder, implementations);

// Register implementations in DI container
builder.Services.AddSingleton(implementations);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.MapGet("/users", async (string implementationName, HttpContext httpContext, [FromServices] Dictionary<string, object> implementations) =>
{
    // Extract query parameters manually
    var parameters = httpContext.Request.Query.ToDictionary(kvp => kvp.Key, kvp => kvp.Value.ToString());
    //UserImplimentationOriginal  ClientOneUsers ClientTwoUsers ClientThreeUsers
    if (implementations.TryGetValue(implementationName, out var implementation))
    {
        var method = implementation.GetType().GetMethod("GetUsersAsync");

        if (method != null)
        {
            if (method.Invoke(implementation, [parameters]) is Task task)
            {
                await task.ConfigureAwait(false);

                var resultProperty = task.GetType().GetProperty("Result");

                if (resultProperty != null)
                {
                    var result = resultProperty.GetValue(task);
                    return Results.Ok(result);
                }
            }
        }

        return Results.BadRequest("Method not found on implementation");
    }

    return Results.NotFound("Implementation not found");
});

// Monitor folder for new implementations
var watcher = new FileSystemWatcher(implementationFolder, "*.dll")
{
    IncludeSubdirectories = true,
    EnableRaisingEvents = true
};

watcher.Created += (sender, e) =>
{
    Console.WriteLine($"New file detected: {e.FullPath}");
    LoadImplementations(implementationFolder, implementations);
};

watcher.EnableRaisingEvents = true;

void LoadImplementations(string folder, Dictionary<string, object> implementations)
{
    if (Directory.Exists(folder))
    {
        var subfolders = Directory.GetDirectories(folder);
        foreach (var subfolder in subfolders)
        {
            var dllFiles = Directory.GetFiles(subfolder, "*.dll");
            foreach (var dll in dllFiles)
            {
                var assembly = Assembly.LoadFrom(dll);
                var types = assembly.GetTypes().Where(
                    t => t.GetInterfaces().Any(i => i.IsGenericType 
                    && i.GetGenericTypeDefinition() == typeof(IApiImplementation<>)) 
                    && !t.IsInterface);
                foreach (var type in types)
                {
                    var implementation = Activator.CreateInstance(type);
                    if (implementation != null)
                    {
                        Console.WriteLine($"Loaded implementation: {type.Name}");
                        implementations[type.Name] = implementation;
                    }
                }
            }
        }
    }
}

app.Run();
 