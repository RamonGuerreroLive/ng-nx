﻿using cf.interfaces;
using System.Text.Json;

namespace cf.client.one
{
    public class User : IUser
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string UserName { get; set; }
    }

    public class ClientOneUsers : IApiImplementation<User>
    {
        public async Task<List<User>> GetUsersAsync(Dictionary<string, string> parameters)
        {
            using var client = new HttpClient();
            var response = await client.GetStringAsync("https://jsonplaceholder.typicode.com/users");
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
 
            var users = JsonSerializer.Deserialize<List<User>>(response, options);
            return users ?? [];

        }
    }
}
