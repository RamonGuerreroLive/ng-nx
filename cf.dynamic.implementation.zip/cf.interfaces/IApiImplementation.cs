﻿
namespace cf.interfaces
{
    public interface IUser
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public interface IApiImplementation<T> where T : IUser
    {
        Task<List<T>> GetUsersAsync(Dictionary<string, string> parameters);
    }
}
