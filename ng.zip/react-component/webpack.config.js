const path = require('path');

module.exports = {
    entry: {
        'react-component': './src/index.tsx',
        'second-react-component': './src/second-index.tsx',
        'kanban-component': './src/kanban-index.tsx',
        'youtube-component': './src/youtube-index.tsx'
    },
    output: {
        path: path.resolve(__dirname, '../src/assets/react'),
        filename: '[name].js',
        library: {
            type: 'umd',
            name: '[name]'
        }
    },
    module: {
        rules: [
            {
                test: /\.(ts|tsx)$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-react', '@babel/preset-typescript']
                    }
                }
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            }
        ]
    },
    resolve: {
        extensions: ['.tsx', '.ts', '.js']
    },
    externals: {
        react: 'React',
        'react-dom': 'ReactDOM'
    },
    mode: 'production'
}; 