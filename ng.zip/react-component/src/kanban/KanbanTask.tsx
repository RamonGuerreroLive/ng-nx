import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Task } from './types';
import './KanbanComponent.css';

interface KanbanTaskProps {
    task: Task;
}

export const KanbanTask: React.FC<KanbanTaskProps> = ({ task }) => {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging,
    } = useSortable({ id: task.id });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition: transition,
        opacity: isDragging ? 0.5 : 1,
        backgroundColor: '#fff',
        border: '1px solid #e0e0e0',
        borderRadius: '4px',
        padding: '12px',
        marginBottom: '8px',
        cursor: 'grab',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    };

    return (
        <div
            ref={setNodeRef}
            style={style}
            className="task-card"
            {...attributes}
            {...listeners}
        >
            <h4 style={{ margin: '0 0 8px 0', fontSize: '16px', color: '#333' }}>{task.title}</h4>
            <p style={{ margin: 0, fontSize: '14px', color: '#666' }}>{task.description}</p>
        </div>
    );
}; 