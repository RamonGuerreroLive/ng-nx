import React from 'react';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { Task } from './types';
import { KanbanTask } from './KanbanTask';
import './KanbanComponent.css';

interface KanbanColumnProps {
    id: string;
    title: string;
    tasks: Task[];
}

export const KanbanColumn: React.FC<KanbanColumnProps> = ({ id, title, tasks }) => {
    return (
        <div className="kanban-column" style={{ flex: 1, backgroundColor: '#fff', borderRadius: '8px', padding: '16px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
            <h3 className="column-title" style={{ margin: '0 0 16px 0', fontSize: '18px', color: '#333', textAlign: 'center' }}>{title}</h3>
            <SortableContext items={tasks.map(task => task.id)} strategy={verticalListSortingStrategy}>
                <div className="task-list" style={{ minHeight: '100px' }}>
                    {tasks.map((task) => (
                        <KanbanTask key={task.id} task={task} />
                    ))}
                </div>
            </SortableContext>
        </div>
    );
}; 