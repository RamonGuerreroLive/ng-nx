import React, { useState, useEffect } from 'react';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { KanbanColumn } from './KanbanColumn';
import { Task } from './types';
import './KanbanComponent.css';

const columns = [
    { id: 'todo', title: 'To Do' },
    { id: 'in-progress', title: 'In Progress' },
    { id: 'done', title: 'Done' },
];

interface KanbanComponentProps {
    todoTasks?: Omit<Task, 'status'>[];
    inProgressTasks?: Omit<Task, 'status'>[];
    doneTasks?: Omit<Task, 'status'>[];
}

export const KanbanComponent: React.FC<KanbanComponentProps> = ({
    todoTasks = [],
    inProgressTasks = [],
    doneTasks = []
}) => {
    const [tasks, setTasks] = useState<Task[]>([]);

    useEffect(() => {
        // Combine all tasks and ensure they have the correct status
        const allTasks: Task[] = [
            ...todoTasks.map(task => ({ ...task, status: 'todo' as const })),
            ...inProgressTasks.map(task => ({ ...task, status: 'in-progress' as const })),
            ...doneTasks.map(task => ({ ...task, status: 'done' as const }))
        ];
        setTasks(allTasks);
    }, [todoTasks, inProgressTasks, doneTasks]);

    const [activeId, setActiveId] = useState<string | null>(null);

    const sensors = useSensors(
        useSensor(PointerSensor),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );

    const handleDragStart = (event: any) => {
        setActiveId(event.active.id);
    };

    const handleDragEnd = (event: any) => {
        const { active, over } = event;

        if (active.id !== over?.id) {
            setTasks((items) => {
                const oldIndex = items.findIndex((item) => item.id === active.id);
                const newIndex = items.findIndex((item) => item.id === over.id);
                return arrayMove(items, oldIndex, newIndex);
            });
        }
        setActiveId(null);
    };

    const handleDragOver = (event: any) => {
        const { active, over } = event;
        if (!over) return;

        const activeTask = tasks.find((task) => task.id === active.id);
        const overTask = tasks.find((task) => task.id === over.id);

        if (activeTask && overTask && activeTask.status !== overTask.status) {
            setTasks((items) =>
                items.map((item) =>
                    item.id === active.id ? { ...item, status: overTask.status } : item
                )
            );
        }
    };

    return (
        <div className="kanban-board" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragStart={handleDragStart}
                onDragEnd={handleDragEnd}
                onDragOver={handleDragOver}
            >
                <div className="kanban-columns" style={{ display: 'flex', gap: '20px', flex: 1 }}>
                    {columns.map((column) => (
                        <KanbanColumn
                            key={column.id}
                            id={column.id}
                            title={column.title}
                            tasks={tasks.filter((task) => task.status === column.id)}
                        />
                    ))}
                </div>
            </DndContext>
        </div>
    );
}; 