import React from 'react';
import { createRoot } from 'react-dom/client';
import { KanbanComponent } from './kanban/KanbanComponent';
import { Task } from './kanban/types';

// Create a custom element for the Kanban component
class KanbanWebComponent extends HTMLElement {
    private root: any;
    private mountPoint: HTMLDivElement;
    private _todoTasks: Omit<Task, 'status'>[] = [];
    private _inProgressTasks: Omit<Task, 'status'>[] = [];
    private _doneTasks: Omit<Task, 'status'>[] = [];

    constructor() {
        super();
        this.mountPoint = document.createElement('div');
        this.attachShadow({ mode: 'open' });
        this.shadowRoot?.appendChild(this.mountPoint);
    }

    // Getters and setters for properties
    get todoTasks() {
        return this._todoTasks;
    }

    set todoTasks(value: Omit<Task, 'status'>[]) {
        this._todoTasks = value;
        this.updateComponent();
    }

    get inProgressTasks() {
        return this._inProgressTasks;
    }

    set inProgressTasks(value: Omit<Task, 'status'>[]) {
        this._inProgressTasks = value;
        this.updateComponent();
    }

    get doneTasks() {
        return this._doneTasks;
    }

    set doneTasks(value: Omit<Task, 'status'>[]) {
        this._doneTasks = value;
        this.updateComponent();
    }

    connectedCallback() {
        this.root = createRoot(this.mountPoint);
        this.updateComponent();
    }

    private updateComponent() {
        if (!this.root) return;

        this.root.render(
            <KanbanComponent
                todoTasks={this._todoTasks}
                inProgressTasks={this._inProgressTasks}
                doneTasks={this._doneTasks}
            />
        );
    }

    disconnectedCallback() {
        this.root?.unmount();
    }

    static get observedAttributes() {
        return ['todo-tasks', 'in-progress-tasks', 'done-tasks'];
    }

    attributeChangedCallback(name: string, oldValue: string, newValue: string) {
        if (oldValue !== newValue) {
            try {
                const value = JSON.parse(newValue);
                switch (name) {
                    case 'todo-tasks':
                        this.todoTasks = value;
                        break;
                    case 'in-progress-tasks':
                        this.inProgressTasks = value;
                        break;
                    case 'done-tasks':
                        this.doneTasks = value;
                        break;
                }
            } catch (error) {
                console.error(`Failed to parse ${name}:`, error);
            }
        }
    }
}

// Register the custom element
customElements.define('kanban-component', KanbanWebComponent); 