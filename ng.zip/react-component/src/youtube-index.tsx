import React from 'react';
import { createRoot } from 'react-dom/client';
import { YoutubePlayer } from './youtube/YoutubePlayer';

// Create a custom element for the YouTube component
class YoutubeWebComponent extends HTMLElement {
    private root: any;
    private mountPoint: HTMLDivElement;

    constructor() {
        super();
        this.mountPoint = document.createElement('div');
        this.attachShadow({ mode: 'open' });
        this.shadowRoot?.appendChild(this.mountPoint);
    }

    connectedCallback() {
        this.root = createRoot(this.mountPoint);
        const videoId = this.getAttribute('video-id') || 'dQw4w9WgXcQ'; // Default video ID
        this.root.render(<YoutubePlayer videoId={videoId} />);
    }

    disconnectedCallback() {
        this.root?.unmount();
    }

    static get observedAttributes() {
        return ['video-id'];
    }

    attributeChangedCallback(name: string, oldValue: string, newValue: string) {
        if (name === 'video-id' && oldValue !== newValue) {
            this.root?.render(<YoutubePlayer videoId={newValue} />);
        }
    }
}

// Register the custom element
customElements.define('youtube-component', YoutubeWebComponent); 