import React, { useState } from 'react';
import './SecondComponent.css';

interface SecondComponentProps {
    message?: string;
}

export const SecondComponent: React.FC<SecondComponentProps> = ({ message = 'Hello from Second React Component!' }) => {
    const [inputValue, setInputValue] = useState('');

    const handleSubmit = () => {
        const event = new CustomEvent('second-react-submit', {
            detail: { value: inputValue },
            bubbles: true,
            composed: true
        });
        document.dispatchEvent(event);
    };

    return (
        <div className="second-component">
            <h2>{message}</h2>
            <p>This is the second React component!</p>
            <div className="input-group">
                <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Enter some text..."
                    className="second-input"
                />
                <button onClick={handleSubmit} className="second-button">
                    Submit
                </button>
            </div>
        </div>
    );
}; 