import React from 'react';
import { createRoot } from 'react-dom/client';
import { MyComponent } from './MyComponent';

class ReactWebComponent extends HTMLElement {
    private root: any;
    private mountPoint: HTMLDivElement;

    constructor() {
        super();
        this.mountPoint = document.createElement('div');
        this.attachShadow({ mode: 'open' });
        this.shadowRoot?.appendChild(this.mountPoint);
    }

    connectedCallback() {
        this.root = createRoot(this.mountPoint);
        const message = this.getAttribute('message') || undefined;
        this.root.render(<MyComponent message={message} />);
    }

    disconnectedCallback() {
        this.root?.unmount();
    }

    static get observedAttributes() {
        return ['message'];
    }

    attributeChangedCallback(name: string, oldValue: string, newValue: string) {
        if (name === 'message' && oldValue !== newValue) {
            this.root?.render(<MyComponent message={newValue} />);
        }
    }
}

customElements.define('react-component', ReactWebComponent); 