import React, { useState } from 'react';
import './MyComponent.css';

interface MyComponentProps {
    message?: string;
}

export const MyComponent: React.FC<MyComponentProps> = ({ message = 'Hello from React!' }) => {
    const [inputValue, setInputValue] = useState('');

    const handleSubmit = () => {
        // Create and dispatch a custom event
        const event = new CustomEvent('react-input-submit', {
            detail: { value: inputValue },
            bubbles: true,
            composed: true // This allows the event to cross the shadow DOM boundary
        });
        document.dispatchEvent(event);
    };

    return (
        <div className="react-component">
            <h2>{message}</h2>
            <p>This is a React component running inside Angular!</p>
            <div className="input-group">
                <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Enter some text..."
                    className="react-input"
                />
                <button onClick={handleSubmit} className="react-button">
                    Submit
                </button>
            </div>
        </div>
    );
}; 