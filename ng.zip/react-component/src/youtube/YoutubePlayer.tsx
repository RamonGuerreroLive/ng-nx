import React from 'react';
import './YoutubePlayer.css';

interface YoutubePlayerProps {
    videoId: string;
}

export const YoutubePlayer: React.FC<YoutubePlayerProps> = ({ videoId }) => {
    return (
        <div className="youtube-player-container">
            <iframe
                className="youtube-player"
                src={`https://www.youtube.com/embed/${videoId}`}
                title="YouTube video player"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
            ></iframe>
        </div>
    );
}; 