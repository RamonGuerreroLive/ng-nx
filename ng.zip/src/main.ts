import { bootstrapApplication } from '@angular/platform-browser';
import { ReactAppComponent } from './app/app.component';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideBrowserGlobalErrorListeners } from '@angular/core';

bootstrapApplication(ReactAppComponent, {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(),
    provideAnimations()
  ]
}).catch(err => console.error(err));
