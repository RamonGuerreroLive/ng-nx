import { Component, OnInit, OnDestroy, Input, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { PluginService, PluginConfig } from '../../services/plugin.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-plugin-loader',
    template: `
        <div #container>
            <div *ngIf="error" class="error-message">
                {{ error }}
            </div>
        </div>
    `,
    styles: [`
        :host {
            display: block;
            width: 100%;
            height: 100%;
        }
        .error-message {
            color: red;
            padding: 10px;
            border: 1px solid red;
            border-radius: 4px;
            margin: 10px 0;
        }
    `],
    standalone: true,
    imports: [CommonModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PluginLoaderComponent implements OnInit, OnDestroy, AfterViewInit {
    @ViewChild('container') container!: ElementRef;
    @Input() pluginId!: string;

    private subscription: Subscription = new Subscription();
    private pluginConfig: PluginConfig | undefined;
    error: string | null = null;

    constructor(private pluginService: PluginService) { }

    ngOnInit() {
        this.subscription.add(
            this.pluginService.getPlugins().subscribe(plugins => {
                if (!plugins || plugins.length === 0) {
                    this.error = 'No plugins available';
                    return;
                }

                this.pluginConfig = plugins.find(p => p.id === this.pluginId);
                if (!this.pluginConfig) {
                    this.error = `Plugin with ID "${this.pluginId}" not found`;
                    return;
                }

                this.error = null;
                this.loadPlugin();
            })
        );
    }

    ngAfterViewInit() {
        if (this.pluginConfig && !this.error) {
            this.loadPlugin();
        }
    }

    private async loadPlugin() {
        if (!this.pluginConfig || !this.container) return;

        try {
            await this.pluginService.loadPluginScript(this.pluginConfig);

            // Create the custom element
            const element = document.createElement(this.pluginConfig.componentTag);

            // Set attributes
            if (this.pluginConfig.attributes) {
                Object.entries(this.pluginConfig.attributes).forEach(([key, value]) => {
                    element.setAttribute(key, value);
                });
            }

            // Set properties
            if (this.pluginConfig.properties) {
                Object.entries(this.pluginConfig.properties).forEach(([key, value]) => {
                    // Convert camelCase to kebab-case for attributes
                    const attributeKey = key.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();

                    // Set both as property and attribute
                    (element as any)[key] = value;
                    element.setAttribute(attributeKey, JSON.stringify(value));
                });
            }

            // Clear container and append the element
            this.container.nativeElement.innerHTML = '';
            this.container.nativeElement.appendChild(element);
        } catch (error) {
            this.error = `Failed to load plugin: ${error}`;
            console.error('Failed to load plugin:', error);
        }
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
} 