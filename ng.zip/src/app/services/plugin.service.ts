import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface PluginConfig {
    id: string;
    name: string;
    scriptPath: string;
    componentTag: string;
    attributes?: { [key: string]: string };
    properties?: { [key: string]: any };
}

interface PluginConfigResponse {
    plugins: PluginConfig[];
}

@Injectable({
    providedIn: 'root'
})
export class PluginService {
    private loadedScripts = new Set<string>();
    private plugins = new BehaviorSubject<PluginConfig[]>([]);

    constructor() {
        // Load plugin configurations
        this.loadPluginConfigs();
    }

    private async loadPluginConfigs() {
        try {
            const response = await fetch('assets/plugins/plugins.json');
            const data: PluginConfigResponse = await response.json();
            this.plugins.next(data.plugins);
        } catch (error) {
            console.error('Failed to load plugin configurations:', error);
            this.plugins.next([]);
        }
    }

    getPlugins(): Observable<PluginConfig[]> {
        return this.plugins.asObservable();
    }

    async loadPluginScript(config: PluginConfig): Promise<void> {
        if (this.loadedScripts.has(config.scriptPath)) {
            return;
        }

        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = config.scriptPath;
            script.async = true;

            script.onload = () => {
                this.loadedScripts.add(config.scriptPath);
                resolve();
            };

            script.onerror = () => {
                reject(new Error(`Failed to load script: ${config.scriptPath}`));
            };

            document.head.appendChild(script);
        });
    }
} 