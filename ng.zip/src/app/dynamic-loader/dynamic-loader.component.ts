import { Component, OnInit, OnDestroy, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
    selector: 'app-dynamic-loader',
    template: `
    <div class="dynamic-loader">
      <h2>Dynamic Component Loader</h2>
      <div #container></div>
      <button (click)="loadComponent()" [disabled]="isLoading">
        {{ isLoading ? 'Loading...' : 'Load React Component' }}
      </button>
    </div>
  `,
    styles: [`
    .dynamic-loader {
      padding: 20px;
      background-color: #f0f0f0;
      border-radius: 8px;
      margin: 20px;
    }
    button {
      padding: 8px 16px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      margin-top: 10px;
    }
    button:disabled {
      background-color: #cccccc;
      cursor: not-allowed;
    }
  `],
    standalone: true,
    imports: [CommonModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DynamicLoaderComponent implements OnInit, OnDestroy, AfterViewInit {
    @ViewChild('container') container!: ElementRef;
    protected isLoading = false;
    private scriptLoaded = false;
    private eventListener: any;

    constructor() { }

    ngOnInit(): void {
        // Check if script is already loaded
        this.scriptLoaded = !!document.querySelector('script[src="assets/react/react-component.js"]');

        // Set up event listener for React component events
        this.eventListener = (event: CustomEvent) => {
            console.log('%c Received from Dynamically Loaded React Component:', 'background: #61dafb; color: #282c34; padding: 2px 5px; border-radius: 3px;');
            console.log('%c ' + event.detail.value, 'color: #61dafb; font-weight: bold;');
        };
        document.addEventListener('react-input-submit', this.eventListener as EventListener);
    }

    ngAfterViewInit(): void {
        // If script is already loaded, we can create the component immediately
        if (this.scriptLoaded) {
            this.createReactComponent();
        }
    }

    async loadComponent(): Promise<void> {
        if (this.isLoading) return;

        try {
            this.isLoading = true;

            if (!this.scriptLoaded) {
                await this.loadScript();
                this.scriptLoaded = true;
            }

            this.createReactComponent();
        } catch (error) {
            console.error('Failed to load component:', error);
        } finally {
            this.isLoading = false;
        }
    }

    private loadScript(): Promise<void> {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'assets/react/react-component.js';
            script.onload = () => resolve();
            script.onerror = () => reject(new Error('Failed to load script'));
            document.head.appendChild(script);
        });
    }

    private createReactComponent(): void {
        const element = document.createElement('react-component');
        element.setAttribute('message', 'Loaded Dynamically!');
        this.container.nativeElement.appendChild(element);
    }

    ngOnDestroy(): void {
        document.removeEventListener('react-input-submit', this.eventListener as EventListener);
    }
} 