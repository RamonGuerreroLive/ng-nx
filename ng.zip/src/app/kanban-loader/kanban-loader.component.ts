import { Component, OnInit, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
    selector: 'app-kanban-loader',
    template: '<kanban-component></kanban-component>',
    styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
    standalone: true,
    imports: [CommonModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class KanbanLoaderComponent implements OnInit {
    private scriptLoaded = false;

    ngOnInit() {
        this.loadScript();
    }

    private loadScript() {
        if (this.scriptLoaded) return;

        const script = document.createElement('script');
        script.src = 'assets/react/kanban-component.js';
        script.async = true;
        script.onload = () => {
            this.scriptLoaded = true;
        };
        document.head.appendChild(script);
    }
} 