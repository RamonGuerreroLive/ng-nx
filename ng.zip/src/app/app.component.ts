import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PluginLoaderComponent } from './components/plugin-loader/plugin-loader.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, PluginLoaderComponent],
  template: `
    <div class="container">
      <h1>Angular App with React Components</h1>
      <div class="components">
        <div class="component">
          <h2>YouTube Player</h2>
          <app-plugin-loader pluginId="youtube-player"></app-plugin-loader>
        </div>
        <div class="component">
          <h2>Kanban Board</h2>
          <app-plugin-loader pluginId="kanban-board"></app-plugin-loader>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .container {
      padding: 20px;
    }
    .components {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }
    .component {
      border: 1px solid #ccc;
      padding: 20px;
      border-radius: 8px;
    }
    h1 {
      text-align: center;
      color: #333;
    }
    h2 {
      color: #666;
      margin-bottom: 15px;
    }
  `]
})
export class ReactAppComponent {
  title = 'ng-react';
} 