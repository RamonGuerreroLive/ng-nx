import { Component, OnInit, OnDestroy, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
    selector: 'app-second-loader',
    template: `
    <div class="second-loader">
      <h2>Second Component Loader</h2>
      <div #container></div>
      <button (click)="loadComponent()" [disabled]="isLoading">
        {{ isLoading ? 'Loading...' : 'Load Second React Component' }}
      </button>
    </div>
  `,
    styles: [`
    .second-loader {
      padding: 20px;
      background-color: #f8f9fa;
      border-radius: 8px;
      margin: 20px;
    }
    button {
      padding: 8px 16px;
      background-color: #ff6b6b;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      margin-top: 10px;
    }
    button:disabled {
      background-color: #ffc9c9;
      cursor: not-allowed;
    }
  `],
    standalone: true,
    imports: [CommonModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SecondLoaderComponent implements OnInit, OnDestroy, AfterViewInit {
    @ViewChild('container') container!: ElementRef;
    protected isLoading = false;
    private scriptLoaded = false;
    private eventListener: any;

    constructor() { }

    ngOnInit(): void {
        this.scriptLoaded = !!document.querySelector('script[src="assets/react/second-react-component.js"]');

        this.eventListener = (event: CustomEvent) => {
            console.log('%c Received from Second React Component:', 'background: #ff6b6b; color: #2d3436; padding: 2px 5px; border-radius: 3px;');
            console.log('%c ' + event.detail.value, 'color: #ff6b6b; font-weight: bold;');
        };
        document.addEventListener('second-react-submit', this.eventListener as EventListener);
    }

    ngAfterViewInit(): void {
        if (this.scriptLoaded) {
            this.createReactComponent();
        }
    }

    async loadComponent(): Promise<void> {
        if (this.isLoading) return;

        try {
            this.isLoading = true;

            if (!this.scriptLoaded) {
                await this.loadScript();
                this.scriptLoaded = true;
            }

            this.createReactComponent();
        } catch (error) {
            console.error('Failed to load component:', error);
        } finally {
            this.isLoading = false;
        }
    }

    private loadScript(): Promise<void> {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'assets/react/second-react-component.js';
            script.onload = () => resolve();
            script.onerror = () => reject(new Error('Failed to load script'));
            document.head.appendChild(script);
        });
    }

    private createReactComponent(): void {
        const element = document.createElement('second-react-component');
        element.setAttribute('message', 'Loaded Dynamically!');
        this.container.nativeElement.appendChild(element);
    }

    ngOnDestroy(): void {
        document.removeEventListener('second-react-submit', this.eventListener as EventListener);
    }
} 