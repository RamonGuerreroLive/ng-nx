import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
    selector: 'app-react-wrapper',
    template: `
    <div class="react-wrapper">
      <h1>Angular Component</h1>
      <react-component message="Hello from Angular!"></react-component>
    </div>
  `,
    styles: [`
    .react-wrapper {
      padding: 20px;
      background-color: #f5f5f5;
      border-radius: 8px;
      margin: 20px;
    }
  `],
    standalone: true,
    imports: [CommonModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ReactWrapperComponent implements OnInit, OnDestroy {
    private eventListener: any;

    constructor() { }

    ngOnInit(): void {
        // Listen for the custom event from React
        this.eventListener = (event: CustomEvent) => {
            console.log('%c Received from React:', 'background: #61dafb; color: #282c34; padding: 2px 5px; border-radius: 3px;');
            console.log('%c ' + event.detail.value, 'color: #61dafb; font-weight: bold;');
        };

        document.addEventListener('react-input-submit', this.eventListener as EventListener);
    }

    ngOnDestroy(): void {
        // Clean up the event listener
        document.removeEventListener('react-input-submit', this.eventListener as EventListener);
    }
} 