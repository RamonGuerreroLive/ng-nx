import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
    selector: 'app-youtube-loader',
    template: '<youtube-component [attr.video-id]="videoId"></youtube-component>',
    styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
    standalone: true,
    imports: [CommonModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class YoutubeLoaderComponent implements OnInit {
    @Input() videoId: string = 'dQw4w9WgXcQ'; // Default video ID
    private scriptLoaded = false;

    ngOnInit() {
        this.loadScript();
    }

    private loadScript() {
        if (this.scriptLoaded) return;

        const script = document.createElement('script');
        script.src = 'assets/react/youtube-component.js';
        script.async = true;
        script.onload = () => {
            this.scriptLoaded = true;
        };
        document.head.appendChild(script);
    }
} 