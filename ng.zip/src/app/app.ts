import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ReactWrapperComponent } from './react-wrapper/react-wrapper.component';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, ReactWrapperComponent],
  template: `
    <h1>Welcome to {{title}}!</h1>
 <app-react-wrapper></app-react-wrapper>
 
  `,
  styles: [],
})
export class App {
  protected title = 'ng-react';
}
